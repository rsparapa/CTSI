Here is a list of files and their description

breastcodes.sas SAS program for RASMACRO breast cancer example
breastcodes.lst and the corresponing output
breast.all.hcpcs.table.txt breast cancer HCPCS/CPT codes
colorectal.all.hcpcs.table.txt colorectal cancer HCPCS/CPT codes
HCPC17_CONTR_ANWEB.csv HCPCS descriptions
hcpcs.sas importing HCPCS descriptions
medispan.csv Medi-Span, GPI, RxNorm medical nomenclature 
readme.txt this file
slides.pdf the presentation slides
snippet*.R R program snippets for hands-on examples
